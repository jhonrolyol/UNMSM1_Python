''' PROBLEMA N° 3
Realizar un programa que incluya una función que, dado
un número de DNI, retorne True si el número es válido y False
si no lo es. Para que un número de DNI sea válido debe tener
entre 7 y 8 dígitos.
'''
print("=============================================")
print("===========  BIENVENIDO AL PROGRAMA =========")
print("=============================================")

def DNI():
    NumeroDeDNI = 1234567
    if NumeroDeDNI == 1234567:
       print('True')
    else:
       print('False')
DNI()


print("=============================================")
print("============== FINAL DEL PROGRAMA ===========")
print("=============================================")
