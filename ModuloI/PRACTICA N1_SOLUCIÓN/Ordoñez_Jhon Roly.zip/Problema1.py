''' PROBLEMA N°1:
Escribir un programa que pregunte el nombre
del usuario en la consola y después
de que el usuario lo introduzca muestre
por pantalla la cadena ¡Hola <nombre>!,
donde <nombre> es el nombre que el
usuario haya introducido.
'''
print("================================================")
print("========= BIENVENIDO AL PROGRAMA ===============")
print("================================================")

# ENTRADA
NombreDelUsuario = input("¿Por favor, introdusca su nombre?\n")
# SALIDA
print(f"¡Hola, {NombreDelUsuario}!")

print("================================================")
print("=============== FIN DEL PROGRAMA ===============")
print("================================================")

